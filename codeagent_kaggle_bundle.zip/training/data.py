"""Dataset validation, grouped splits, and assistant-only tokenization.

Local port of the Colab notebook's Cells 3-4. The logic is kept identical so
local results stay comparable with the Colab run. Nothing here is relaxed:
the pilot path still requires human-written approval files.
"""
from __future__ import annotations

import hashlib
import json
from collections import Counter, defaultdict
from collections.abc import Mapping
from pathlib import Path

REQUIRED_FIELDS = {"id", "group_id", "category", "messages", "tools", "provenance", "self_contained"}
ALLOWED_CATEGORIES = {"repository", "tool", "coding"}
ALLOWED_MESSAGE_KEYS = {"role", "content", "tool_calls", "tool_call_id", "name"}
SMOKE_SOURCE = "project-authored-scripted-demo"
PILOT_REQUIRED_BASELINE_ATTEMPTS = 60
PILOT_MIN_GROUPS = 20


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def save_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding="utf-8")


def read_jsonl(path):
    with open(path, "r", encoding="utf-8-sig") as handle:
        return [json.loads(line) for line in handle if line.strip()]


def write_jsonl(path, rows):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        for row in rows:
            handle.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")


def sha256_file(path):
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def sha256_obj(value):
    payload = json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def validate_rows(rows):
    """Schema and licence gate. Raises on the first bad record."""
    for row in rows:
        missing = REQUIRED_FIELDS - set(row)
        if missing:
            raise ValueError(f"{row.get('id')}: missing fields {sorted(missing)}")
        if row["category"] not in ALLOWED_CATEGORIES:
            raise ValueError(f"{row['id']}: unknown category {row['category']!r}")
        if row["self_contained"] is not True:
            raise ValueError(f"{row['id']}: self_contained must be true")
        prov = row["provenance"]
        if not prov.get("source") or not prov.get("revision"):
            raise ValueError(f"{row['id']}: provenance needs source and revision")
        if prov.get("license_review") != "approved":
            raise ValueError(f"Unapproved record: {row['id']}")
        if not any(m.get("role") == "assistant" for m in row["messages"]):
            raise ValueError(f"{row['id']}: no assistant turn")


def make_smoke_splits(rows):
    """Group-separated smoke split. Only project-authored demos are accepted."""
    if not all(r["provenance"].get("source") == SMOKE_SOURCE for r in rows):
        raise ValueError("Smoke mode accepts only project-authored recorded demos.")
    by_group = defaultdict(list)
    for row in rows:
        by_group[row["group_id"]].append(row)
    if len(by_group) < 5:
        raise ValueError("Smoke mode requires at least five independent task-family groups.")

    group_category = {
        g: Counter(r["category"] for r in rs).most_common(1)[0][0] for g, rs in by_group.items()
    }
    train_groups = []
    for category in ("repository", "tool", "coding"):
        options = sorted(g for g, c in group_category.items() if c == category and g not in train_groups)
        if not options:
            raise ValueError(f"No independent group available for training category {category}.")
        train_groups.append(options[0])

    remaining = sorted(set(by_group) - set(train_groups))
    if len(remaining) < 2:
        raise ValueError("Need separate validation and test groups.")
    val_groups, test_groups = {remaining[0]}, {remaining[1]}
    train_groups = set(train_groups + remaining[2:])
    return {
        "train": [r for g in sorted(train_groups) for r in by_group[g]],
        "validation": [r for g in sorted(val_groups) for r in by_group[g]],
        "test": [r for g in sorted(test_groups) for r in by_group[g]],
    }


def check_pilot_approvals(data_dir, model_id, revision):
    """Human gates. Pilot training is refused unless every approval file says yes."""
    data_dir = Path(data_dir)
    review = read_json(data_dir / "review.json")
    base = read_json(data_dir / "baseline-7b.json")
    challenger = read_json(data_dir / "baseline-9b.json")
    approval = read_json(data_dir / "training-approval.json")

    if review.get("licenses_approved") is not True or review.get("samples_reviewed") is not True:
        raise ValueError("Pilot blocked: review.json must have licenses_approved and samples_reviewed set to true by a human reviewer.")
    for name, evidence in (("baseline-7b", base), ("baseline-9b", challenger)):
        ok = (
            evidence.get("complete") is True
            and evidence.get("valid_attempts") == PILOT_REQUIRED_BASELINE_ATTEMPTS
            and evidence.get("infrastructure_errors") == 0
        )
        if not ok:
            raise ValueError(f"Pilot blocked: {name} evidence is incomplete ({PILOT_REQUIRED_BASELINE_ATTEMPTS} valid attempts, 0 infra errors required).")
    approved_models = approval.get("approved_models", [approval.get("approved_model")])
    if model_id not in approved_models and approval.get("approved_model") != model_id:
        raise ValueError(f"Pilot blocked: training-approval.json does not approve model {model_id}.")


def load_pilot_splits(data_dir):
    data_dir = Path(data_dir)
    splits = {name: read_jsonl(data_dir / f"{name}.jsonl") for name in ("train", "validation", "test")}
    if not all(splits.values()):
        raise ValueError("Pilot mode requires non-empty train, validation and test splits.")
    groups = {name: {r["group_id"] for r in rows} for name, rows in splits.items()}
    if len(set().union(*groups.values())) < PILOT_MIN_GROUPS:
        raise ValueError(f"Pilot mode requires at least {PILOT_MIN_GROUPS} independent groups.")
    for a, b in (("train", "validation"), ("train", "test"), ("validation", "test")):
        if groups[a] & groups[b]:
            raise ValueError(f"Group leakage between {a} and {b}.")
    return splits


def build_audit(mode, source_rows, splits):
    split_groups = {name: sorted({r["group_id"] for r in rows}) for name, rows in splits.items()}
    return {
        "authorization": "smoke_only" if mode == "smoke" else "reviewed_pilot",
        "splits": {
            name: {
                "examples": len(rows),
                "groups": split_groups[name],
                "categories": dict(Counter(r["category"] for r in rows)),
            }
            for name, rows in splits.items()
        },
        "source_records": len(source_rows),
        "source_hash": sha256_obj(source_rows),
        "warning": (
            "Smoke mode validates mechanics only; it is not evidence of a generally improved coding model."
            if mode == "smoke" else None
        ),
    }


def encode_record(row, tokenizer, max_length):
    """Tokenize with the chat template and supervise only assistant turns."""
    messages = [{k: v for k, v in m.items() if k in ALLOWED_MESSAGE_KEYS} for m in row["messages"]]
    kwargs = {"tools": row["tools"]} if row.get("tools") else {}

    def render(msgs, generation=False):
        result = tokenizer.apply_chat_template(msgs, tokenize=True, add_generation_prompt=generation, **kwargs)
        if hasattr(result, "input_ids"):
            result = result.input_ids
        elif isinstance(result, (Mapping, dict)) or (hasattr(result, "__getitem__") and "input_ids" in result):
            result = result["input_ids"]
        return list(result)

    full = render(messages)
    labels = [-100] * len(full)
    for i, message in enumerate(messages):
        if message["role"] != "assistant" or row["messages"][i].get("loss", True) is False:
            continue
        prev_through = render(messages[:i], False) if i > 0 else []
        through = render(messages[: i + 1], False)
        if not (full[: len(through)] == through and len(prev_through) < len(through)):
            raise ValueError(f"Template mask alignment failed: {row['id']}")

        turn_tokens = full[len(prev_through): len(through)]
        start_idx = len(prev_through) + 3
        for offset in range(len(turn_tokens) - 1):
            if turn_tokens[offset] == 151644 and turn_tokens[offset + 1] == 77091:
                idx = offset + 2
                while idx < len(turn_tokens) and turn_tokens[idx] == 198:
                    idx += 1
                start_idx = len(prev_through) + idx
                break
        end_idx = len(through)
        labels[start_idx:end_idx] = full[start_idx:end_idx]

    if len(full) > max_length:
        raise ValueError(f"Overlength record {row['id']}: {len(full)} > {max_length}")
    if all(x == -100 for x in labels):
        raise ValueError(f"No supervised tokens: {row['id']}")
    return {"input_ids": full, "attention_mask": [1] * len(full), "labels": labels, "record_id": row["id"]}


def apply_token_cap(rows, cap):
    """Keep training examples in order until the token budget is spent."""
    if cap is None:
        return rows
    total, kept = 0, []
    for item in rows:
        if total + len(item["input_ids"]) > cap:
            break
        kept.append(item)
        total += len(item["input_ids"])
    if not kept:
        raise ValueError("No complete training example fits the token cap.")
    return kept


def token_stats(encoded):
    return {
        name: {
            "examples": len(items),
            "input_tokens": sum(len(x["input_ids"]) for x in items),
            "supervised_tokens": sum(sum(v != -100 for v in x["labels"]) for x in items),
            "max_length": max(len(x["input_ids"]) for x in items),
        }
        for name, items in encoded.items()
    }
