"""QLoRA SFT for Qwen2.5-Coder-7B-Instruct on a local NVIDIA GPU (Windows 11 or WSL).

Local port of the Colab notebook (Cells 1-8). Same data gates, same LoRA
config, same assistant-only loss. Colab-only pieces are replaced:
  - Google Drive mount and /content paths  -> local project folders
  - per-checkpoint Drive zip uploads        -> local checkpoints only
  - Drive-stored export                     -> local export zip + SHA-256 manifest

Run from the project root, inside the activated conda environment:
    python training\\train.py --mode smoke
    python training\\train.py --mode pilot
"""
from __future__ import annotations

import argparse
import datetime
import gc
import json
import math
import os
os.environ.setdefault("PYTORCH_CUDA_ALLOC_CONF", "expandable_segments:True")
import platform
import shutil
import sys
import uuid
import zipfile
from pathlib import Path

import yaml

sys.path.insert(0, str(Path(__file__).resolve().parent))
from data import (  # noqa: E402
    apply_token_cap,
    build_audit,
    check_pilot_approvals,
    encode_record,
    load_pilot_splits,
    make_smoke_splits,
    read_json,
    read_jsonl,
    save_json,
    sha256_file,
    token_stats,
    validate_rows,
    write_jsonl,
)

GiB = 1024 ** 3
DEFAULT_ROOT = os.environ.get(
    "CODEAGENT_ROOT",
    str(Path(__file__).resolve().parent.parent)
)


def utc_run_id():
    stamp = datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    return f"{stamp}-{uuid.uuid4().hex[:8]}"


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--mode", choices=["smoke", "pilot"], default="smoke")
    parser.add_argument("--root", default=DEFAULT_ROOT, help="Project root (dataset/ and training/ live under it).")
    parser.add_argument("--config", default=str(Path(__file__).resolve().parent / "configs" / "base.yaml"))
    parser.add_argument("--data-dir", default=None, help="Defaults to <root>/dataset/source.")
    parser.add_argument("--new-run", action="store_true", help="Do not resume an unfinished run of this mode.")
    parser.add_argument("--device", choices=["auto", "cuda", "cpu"], default="auto", help="Compute device (auto, cuda, cpu).")
    parser.add_argument("--model-id", default=None, help="Override model ID (e.g. Qwen/Qwen2.5-Coder-0.5B-Instruct for fast local run).")
    parser.add_argument("--max-steps", type=int, default=None, help="Override maximum training steps.")
    return parser.parse_args()


def load_config(path, mode):
    raw = yaml.safe_load(Path(path).read_text(encoding="utf-8"))
    shared = {k: v for k, v in raw.items() if k not in ("smoke", "pilot")}
    return {**shared, **raw[mode]}


def main():
    args = parse_args()
    cfg = load_config(args.config, args.mode)
    if args.model_id:
        cfg["model_id"] = args.model_id
        cfg["model_revision"] = None

    root = Path(args.root)
    data_dir = Path(args.data_dir) if args.data_dir else root / "dataset" / "source"
    runs_root = root / "training" / "runs"
    models_root = root / "training" / "models"
    exports_root = root / "training" / "exports"
    for folder in (runs_root, models_root, exports_root):
        folder.mkdir(parents=True, exist_ok=True)

    # Resume an unfinished run of the same mode; otherwise start a new one.
    latest_file = runs_root / f"latest-{args.mode}.json"
    latest = read_json(latest_file) if latest_file.exists() else None
    if latest and latest.get("status") != "complete" and not args.new_run and (runs_root / latest["run_id"]).exists():
        run_id = latest["run_id"]
    else:
        run_id = utc_run_id()
        save_json(latest_file, {"run_id": run_id, "status": "initialized", "mode": args.mode})
    run_dir = runs_root / run_id
    model_dir = models_root / run_id
    run_dir.mkdir(parents=True, exist_ok=True)
    model_dir.mkdir(parents=True, exist_ok=True)
    print("Project root:", root)
    print("Data dir:    ", data_dir)
    print("Run dir:     ", run_dir)

    # ---- Hardware check & setup ----------------------------------------------
    import torch

    has_cuda = torch.cuda.is_available() and args.device != "cpu"
    if args.device == "cuda" and not has_cuda:
        raise SystemExit("CUDA requested but not available on this machine.")

    free_root = shutil.disk_usage(root).free
    if free_root < 3 * GiB:
        raise SystemExit(f"At least 3 GiB free needed under {root}; found {free_root / GiB:.2f} GiB.")

    use_unsloth = False
    use_bnb = False
    if has_cuda:
        try:
            import unsloth  # noqa: F401
            from unsloth import FastLanguageModel
            use_unsloth = True
        except ImportError:
            use_unsloth = False
            print("[INFO] Unsloth not installed. Using standard Hugging Face PEFT + BitsAndBytes 4-bit on CUDA.")
        from peft import PeftModel
        gpu = torch.cuda.get_device_properties(0)
        gpu_name = gpu.name
        vram_bytes = gpu.total_memory
        dtype = torch.bfloat16 if torch.cuda.is_bf16_supported() else torch.float16
        print(f"CUDA GPU detected: {gpu_name} ({vram_bytes / GiB:.2f} GiB)")
    else:
        print("\n[NOTICE] CUDA GPU not detected. Running locally on CPU using Hugging Face transformers + PEFT.")
        gpu_name = "CPU (Local)"
        vram_bytes = 0
        dtype = torch.bfloat16

    from datasets import Dataset
    from transformers import AutoTokenizer, TrainingArguments, Trainer
    from peft import PeftModel

    environment = {
        "python": platform.python_version(),
        "torch": torch.__version__,
        "cuda": torch.version.cuda if has_cuda else None,
        "gpu": gpu_name,
        "vram_bytes": vram_bytes,
        "root_free_bytes": free_root,
        "dtype": str(dtype),
        "run_mode": args.mode,
        "model_id": cfg["model_id"],
        "model_revision": cfg.get("model_revision"),
        "max_length": cfg["max_length"],
        "device": "cuda" if has_cuda else "cpu",
    }
    save_json(run_dir / "environment.json", environment)
    print(json.dumps(environment, indent=2))

    # ---- Data audit and grouped splits (notebook Cell 3) ----------------------
    source_path = data_dir / "all.jsonl" if (data_dir / "all.jsonl").exists() else data_dir / "train.jsonl"
    source_rows = read_jsonl(source_path)
    if not source_rows:
        raise SystemExit(f"No training records found in {source_path}.")
    validate_rows(source_rows)

    if args.mode == "smoke":
        splits = make_smoke_splits(source_rows)
    else:
        check_pilot_approvals(data_dir, cfg["model_id"], cfg["model_revision"])
        splits = load_pilot_splits(data_dir)

    prepared_dir = run_dir / "prepared"
    for name, rows in splits.items():
        write_jsonl(prepared_dir / f"{name}.jsonl", rows)
    audit = build_audit(args.mode, source_rows, splits)
    for name in splits:
        audit["splits"][name]["sha256"] = sha256_file(prepared_dir / f"{name}.jsonl")
    save_json(run_dir / "data-audit.json", audit)
    print(json.dumps(audit["splits"], indent=2))

    # ---- Tokenize with assistant-only labels (notebook Cell 4) ----------------
    tokenizer = AutoTokenizer.from_pretrained(cfg["model_id"], revision=cfg.get("model_revision"), trust_remote_code=True)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token
    encoded = {}
    for name, rows in splits.items():
        enc_rows = []
        skipped_overlength = 0
        for r in rows:
            try:
                enc = encode_record(r, tokenizer, cfg["max_length"])
                enc_rows.append(enc)
            except ValueError as err:
                if "Overlength" in str(err):
                    skipped_overlength += 1
                else:
                    raise
        print(f"Split {name}: encoded {len(enc_rows)} records (skipped {skipped_overlength} overlength > {cfg['max_length']} tokens)")
        encoded[name] = enc_rows
    if cfg.get("token_cap"):
        encoded["train"] = apply_token_cap(encoded["train"], cfg["token_cap"])
    stats = token_stats(encoded)
    save_json(run_dir / "token-stats.json", stats)
    print(json.dumps(stats, indent=2))
    del tokenizer
    gc.collect()
    if has_cuda:
        torch.cuda.empty_cache()

    # ---- Model, LoRA, trainer (notebook Cell 6) -------------------------------
    if has_cuda and use_unsloth:
        model, tok = FastLanguageModel.from_pretrained(
            model_name=cfg["model_id"],
            revision=cfg.get("model_revision"),
            max_seq_length=cfg["max_length"],
            dtype=dtype,
            load_in_4bit=True,
        )
        lora = cfg["lora"]
        model = FastLanguageModel.get_peft_model(
            model,
            r=lora["r"],
            lora_alpha=lora["alpha"],
            lora_dropout=lora["dropout"],
            bias="none",
            target_modules=lora["target_modules"],
            use_gradient_checkpointing="unsloth",
            random_state=cfg["seed"],
        )
    elif has_cuda:
        from transformers import AutoModelForCausalLM, BitsAndBytesConfig
        from peft import LoraConfig, get_peft_model, prepare_model_for_kbit_training

        print(f"Loading {cfg['model_id']} on GPU...")
        tok = AutoTokenizer.from_pretrained(cfg["model_id"], revision=cfg.get("model_revision"), trust_remote_code=True)
        if tok.pad_token is None:
            tok.pad_token = tok.eos_token

        use_bnb = False
        try:
            bnb_config = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_quant_type="nf4",
                bnb_4bit_compute_dtype=dtype,
                bnb_4bit_use_double_quant=True,
            )
            model = AutoModelForCausalLM.from_pretrained(
                cfg["model_id"],
                revision=cfg.get("model_revision"),
                quantization_config=bnb_config,
                device_map="auto",
                trust_remote_code=True,
            )
            model = prepare_model_for_kbit_training(model)
            use_bnb = True
            print("✓ Loaded model with 4-bit BitsAndBytes quantization.")
        except (ImportError, ValueError, Exception) as err:
            print(f"[WARN] 4-bit BitsAndBytes quantization failed: {err}")
            print(f"[INFO] Falling back to loading {cfg['model_id']} in {dtype} across available GPUs...")
            if cfg.get("max_length", 4096) > 2048:
                print(f"[INFO] Lowering max_length to 2048 to prevent CUDA OOM in unquantized 16-bit mode.")
                cfg["max_length"] = 2048
            model = AutoModelForCausalLM.from_pretrained(
                cfg["model_id"],
                revision=cfg.get("model_revision"),
                torch_dtype=dtype,
                device_map="auto",
                trust_remote_code=True,
            )
            if hasattr(model, "gradient_checkpointing_enable"):
                model.gradient_checkpointing_enable(gradient_checkpointing_kwargs={"use_reentrant": False})

        lora = cfg["lora"]
        peft_config = LoraConfig(
            r=lora["r"],
            lora_alpha=lora["alpha"],
            lora_dropout=lora["dropout"],
            bias="none",
            target_modules=lora["target_modules"],
            task_type="CAUSAL_LM",
        )
        model = get_peft_model(model, peft_config)
        model.print_trainable_parameters()
    else:
        from transformers import AutoModelForCausalLM
        from peft import LoraConfig, get_peft_model

        print(f"Loading {cfg['model_id']} on CPU (low_cpu_mem_usage=True)...")
        tok = AutoTokenizer.from_pretrained(cfg["model_id"], revision=cfg.get("model_revision"), trust_remote_code=True)
        if tok.pad_token is None:
            tok.pad_token = tok.eos_token

        model = AutoModelForCausalLM.from_pretrained(
            cfg["model_id"],
            revision=cfg.get("model_revision"),
            torch_dtype=dtype,
            low_cpu_mem_usage=True,
            trust_remote_code=True,
        )
        lora = cfg["lora"]
        peft_config = LoraConfig(
            r=lora["r"],
            lora_alpha=lora["alpha"],
            lora_dropout=lora["dropout"],
            bias="none",
            target_modules=lora["target_modules"],
            task_type="CAUSAL_LM",
        )
        model = get_peft_model(model, peft_config)
        model.print_trainable_parameters()

    def collate(batch):
        width = max(len(x["input_ids"]) for x in batch)
        pad = tok.pad_token_id if tok.pad_token_id is not None else tok.eos_token_id
        result = {}
        for key in ("input_ids", "attention_mask", "labels"):
            fill = -100 if key == "labels" else 0 if key == "attention_mask" else pad
            result[key] = torch.tensor([x[key] + [fill] * (width - len(x[key])) for x in batch])
        return result

    train_ds = Dataset.from_list(encoded["train"])
    val_ds = Dataset.from_list(encoded["validation"])
    test_ds = Dataset.from_list(encoded["test"])
    accumulation = cfg["accumulation"]
    one_pass_steps = max(1, math.ceil(len(train_ds) / accumulation))
    max_steps = min(cfg["smoke_max_steps"], one_pass_steps) if args.mode == "smoke" else one_pass_steps
    if args.max_steps is not None:
        max_steps = args.max_steps

    try:
        from trl import SFTConfig, SFTTrainer
        use_sft = True
    except ImportError:
        use_sft = False

    config_kwargs = dict(
        output_dir=str(run_dir / "checkpoints"),
        per_device_train_batch_size=1,
        per_device_eval_batch_size=1,
        gradient_accumulation_steps=accumulation,
        learning_rate=cfg["learning_rate"],
        lr_scheduler_type=cfg["lr_scheduler_type"],
        warmup_ratio=cfg["warmup_ratio"],
        max_steps=max_steps,
        num_train_epochs=1,
        seed=cfg["seed"],
        data_seed=cfg["seed"],
        optim="adamw_8bit" if (has_cuda and (use_unsloth or use_bnb)) else "adamw_torch",
        fp16=has_cuda and (dtype == torch.float16),
        bf16=has_cuda and (dtype == torch.bfloat16),
        logging_steps=1,
        save_steps=cfg["save_steps"],
        save_total_limit=2,
        eval_strategy="steps",
        eval_steps=cfg["eval_steps"],
        packing=False,
        report_to="none",
        remove_unused_columns=False,
        gradient_checkpointing=True,
        gradient_checkpointing_kwargs={"use_reentrant": False},
        dataloader_num_workers=0,  # Windows: avoid multiprocessing DataLoader issues
    )

    import inspect
    arg_class = SFTConfig if use_sft else TrainingArguments
    supported = set(inspect.signature(arg_class.__init__).parameters)
    if "eval_strategy" not in supported and "evaluation_strategy" in supported:
        config_kwargs["evaluation_strategy"] = config_kwargs.pop("eval_strategy")
    if not use_sft:
        config_kwargs.pop("packing", None)
    if use_sft and "dataset_kwargs" in supported:
        config_kwargs["dataset_kwargs"] = {"skip_prepare_dataset": True}

    config_kwargs = {k: v for k, v in config_kwargs.items() if k in supported}
    train_args = arg_class(**config_kwargs)

    trainer_class = SFTTrainer if use_sft else Trainer
    trainer_kwargs = dict(
        model=model, args=train_args, train_dataset=train_ds, eval_dataset=val_ds, data_collator=collate
    )
    trainer_params = set(inspect.signature(trainer_class.__init__).parameters)
    if "processing_class" in trainer_params:
        trainer_kwargs["processing_class"] = tok
    elif "tokenizer" in trainer_params:
        trainer_kwargs["tokenizer"] = tok
    trainer = trainer_class(**trainer_kwargs)

    base_metrics = trainer.evaluate()
    base_test_metrics = trainer.evaluate(test_ds, metric_key_prefix="base_test")
    checkpoint_dirs = sorted(
        (run_dir / "checkpoints").glob("checkpoint-*"), key=lambda p: int(p.name.split("-")[-1])
    )
    resume_checkpoint = str(checkpoint_dirs[-1]) if checkpoint_dirs else None
    print("Resume checkpoint:", resume_checkpoint)
    train_result = trainer.train(resume_from_checkpoint=resume_checkpoint)
    tuned_metrics = trainer.evaluate()
    tuned_test_metrics = trainer.evaluate(test_ds, metric_key_prefix="tuned_test")

    adapter_dir = run_dir / "adapter"
    model.save_pretrained(adapter_dir)
    tok.save_pretrained(adapter_dir)
    training_result = {
        "run_id": run_id,
        "run_mode": args.mode,
        "global_step": trainer.state.global_step,
        "base_eval_loss": base_metrics.get("eval_loss"),
        "tuned_eval_loss": tuned_metrics.get("eval_loss"),
        "base_test_loss": base_test_metrics.get("base_test_loss"),
        "tuned_test_loss": tuned_test_metrics.get("tuned_test_loss"),
        "peak_vram_bytes": torch.cuda.max_memory_allocated() if has_cuda else 0,
        "train_metrics": train_result.metrics,
        "status": "smoke_complete" if args.mode == "smoke" else "pilot_complete",
    }
    save_json(run_dir / "training-result.json", training_result)
    print(json.dumps(training_result, indent=2))

    # ---- Reload the adapter and run a smoke generation (notebook Cell 7) ------
    del trainer, model
    gc.collect()
    if has_cuda:
        torch.cuda.empty_cache()
        base_check, check_tok = FastLanguageModel.from_pretrained(
            model_name=cfg["model_id"],
            revision=cfg.get("model_revision"),
            max_seq_length=cfg["max_length"],
            dtype=dtype,
            load_in_4bit=True,
        )
        reloaded = PeftModel.from_pretrained(base_check, str(adapter_dir), is_trainable=False)
        FastLanguageModel.for_inference(reloaded)
        infer_device = "cuda"
    else:
        from transformers import AutoModelForCausalLM
        base_check = AutoModelForCausalLM.from_pretrained(
            cfg["model_id"],
            revision=cfg.get("model_revision"),
            torch_dtype=dtype,
            low_cpu_mem_usage=True,
            trust_remote_code=True,
        )
        reloaded = PeftModel.from_pretrained(base_check, str(adapter_dir), is_trainable=False)
        check_tok = tok
        infer_device = "cpu"

    messages = [{"role": "user", "content": "Write a short Python function named add that returns the sum of two numbers."}]
    inputs = check_tok.apply_chat_template(messages, tokenize=True, add_generation_prompt=True, return_tensors="pt").to(infer_device)
    with torch.no_grad():
        output = reloaded.generate(input_ids=inputs, max_new_tokens=64, do_sample=False)
    generated = check_tok.decode(output[0][inputs.shape[-1]:], skip_special_tokens=True)
    if not generated.strip():
        raise SystemExit("Reloaded adapter generated an empty response.")
    save_json(run_dir / "reload-smoke.json", {"prompt": messages[0]["content"], "output": generated, "passed": True})
    print(generated)

    # ---- Package the adapter and export a verified bundle (notebook Cell 8) ---
    model_card = {
        "artifact_type": "PEFT LoRA adapter",
        "base_model": cfg["model_id"],
        "base_revision": cfg["model_revision"],
        "run_id": run_id,
        "run_mode": args.mode,
        "max_length": cfg["max_length"],
        "lora": {"rank": lora["r"], "alpha": lora["alpha"], "dropout": lora["dropout"], "targets": lora["target_modules"]},
        "warning": (
            "Smoke mode uses 20 related project-authored demonstrations and is not evidence of broad model improvement."
            if args.mode == "smoke" else None
        ),
    }
    save_json(adapter_dir / "model-card.json", model_card)
    shutil.copytree(adapter_dir, model_dir / "adapter", dirs_exist_ok=True)

    inventory = {
        p.relative_to(run_dir).as_posix(): {"bytes": p.stat().st_size, "sha256": sha256_file(p)}
        for p in sorted(run_dir.rglob("*")) if p.is_file()
    }
    save_json(run_dir / "artifact-inventory.json", inventory)

    zip_base = exports_root / f"qwen2.5-coder-7b-{args.mode}-{run_id}"
    zip_path = Path(shutil.make_archive(str(zip_base), "zip", root_dir=run_dir))
    zip_info = {"path": str(zip_path), "bytes": zip_path.stat().st_size, "sha256": sha256_file(zip_path)}
    save_json(exports_root / f"{zip_path.stem}.json", zip_info)
    with zipfile.ZipFile(zip_path) as check:
        if check.testzip() is not None:
            raise SystemExit(f"Export zip is corrupt: {zip_path}")

    save_json(
        latest_file,
        {"run_id": run_id, "status": "complete", "mode": args.mode,
         "adapter": str(model_dir / "adapter"), "export": str(zip_path), "sha256": zip_info["sha256"]},
    )
    print(json.dumps({"saved_export": str(zip_path), "sha256": zip_info["sha256"]}, indent=2))
    print("Adapter:", model_dir / "adapter")


if __name__ == "__main__":
    main()
